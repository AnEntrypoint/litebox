#!/bin/sh
# Does the rootful Xwayland actually connect to weston as a Wayland CLIENT? XFCE is confirmed
# running (xfwm4/panel/xfdesktop all alive, exchanging X protocol) but zero page-flips occur once
# it starts, so its pixels never reach the DRM scanout. WAYLAND_DISPLAY is exported before
# Xwayland launches, so the missing-env-var theory is already ruled out -- this captures
# Xwayland's OWN stderr, which no launcher has ever dumped.
echo XW_START
export HOME=/root
export LD_LIBRARY_PATH=/usr/lib/weston:/usr/lib:/lib
export XDG_RUNTIME_DIR=/run/user/0
mkdir -p /root /run/user/0 /tmp/.X11-unix /var/lib/dbus
chmod 700 /run/user/0; chmod 1777 /tmp/.X11-unix; rm -f /run/seatd.sock
dbus-uuidgen --ensure=/var/lib/dbus/machine-id 2>/dev/null || true
export DBUS_SESSION_BUS_ADDRESS=unix:path=/tmp/xfce-bus
dbus-daemon --nofork --nopidfile --nosyslog --address="$DBUS_SESSION_BUS_ADDRESS" --session >/dev/null 2>&1 &
i=0; while [ ! -e /tmp/xfce-bus ] && [ $i -lt 40 ]; do i=$((i+1)); sleep 0.5; done
seatd -l error >/dev/null 2>&1 &
i=0; while [ ! -e /run/seatd.sock ] && [ $i -lt 40 ]; do i=$((i+1)); sleep 0.5; done
weston --backend=drm-backend.so --socket=wayland-0 --use-pixman --shell=kiosk-shell.so > /tmp/weston.out 2>&1 &
i=0; while [ ! -e "$XDG_RUNTIME_DIR/wayland-0" ] && [ $i -lt 120 ]; do i=$((i+1)); sleep 0.5; done
echo "XW_WESTON_SOCKET=$([ -e $XDG_RUNTIME_DIR/wayland-0 ] && echo yes || echo NO) after=$i"

export WAYLAND_DISPLAY=wayland-0
echo "XW_ENV_WAYLAND_DISPLAY=$WAYLAND_DISPLAY"
echo "XW_ENV_XDG_RUNTIME_DIR=$XDG_RUNTIME_DIR"
# -verbose 10 makes Xwayland say which backend it chose.
Xwayland :1 -geometry 1920x1080 -fullscreen -noreset -glamor off -verbose 10 > /tmp/xw.out 2>&1 &
i=0; while [ ! -e /tmp/.X11-unix/X1 ] && [ $i -lt 120 ]; do i=$((i+1)); sleep 0.5; done
echo "XW_X1_SOCKET=$([ -e /tmp/.X11-unix/X1 ] && echo yes || echo NO) after=$i"
sleep 8
echo "=== XW_XWAYLAND_STDERR_BEGIN ==="
cat /tmp/xw.out 2>/dev/null | head -60
echo "=== XW_XWAYLAND_STDERR_END ==="
echo "=== XW_WESTON_STDERR (did it see a new client?) ==="
tail -25 /tmp/weston.out 2>/dev/null
echo XW_DONE
